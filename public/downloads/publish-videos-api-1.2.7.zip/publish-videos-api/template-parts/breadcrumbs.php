<?php
publish_videos_api_render_breadcrumbs();
