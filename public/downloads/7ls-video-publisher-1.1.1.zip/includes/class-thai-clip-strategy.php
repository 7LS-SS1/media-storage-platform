<?php
namespace SevenLS_VP;

class Thai_Clip_Strategy implements Content_Strategy_Interface {
    public function get_mode(): string {
        return 'thai_clip';
    }

    public function get_default_params(): array {
        return [
            'type' => 'thai_clip',
            'bucket' => 'media',
        ];
    }
}
