<?php
namespace SevenLS_VP;

class Av_Movie_Strategy implements Content_Strategy_Interface {
    public function get_mode(): string {
        return 'av_movie';
    }

    public function get_default_params(): array {
        return [
            'type' => 'av_movie',
            'bucket' => 'jav',
        ];
    }
}
