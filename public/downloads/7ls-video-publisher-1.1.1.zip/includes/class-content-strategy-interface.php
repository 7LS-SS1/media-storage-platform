<?php
namespace SevenLS_VP;

interface Content_Strategy_Interface {
    /**
     * Get mode key stored in plugin settings.
     */
    public function get_mode(): string;

    /**
     * Get query/body params applied to every API request.
     */
    public function get_default_params(): array;
}
