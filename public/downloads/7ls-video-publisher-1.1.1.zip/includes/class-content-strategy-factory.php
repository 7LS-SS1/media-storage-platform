<?php
namespace SevenLS_VP;

class Content_Strategy_Factory {
    public static function sanitize_mode(mixed $mode): string {
        return $mode === 'av_movie' ? 'av_movie' : 'thai_clip';
    }

    public static function create(mixed $mode): Content_Strategy_Interface {
        $normalized = self::sanitize_mode($mode);

        if ($normalized === 'av_movie') {
            return new Av_Movie_Strategy();
        }

        return new Thai_Clip_Strategy();
    }
}
