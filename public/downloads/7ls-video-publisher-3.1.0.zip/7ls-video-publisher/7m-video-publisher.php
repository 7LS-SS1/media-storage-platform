<?php
/**
 * Compatibility loader for older installs that stored the previous 7M file name.
 */

require_once __DIR__ . '/7ls-video-publisher.php';
