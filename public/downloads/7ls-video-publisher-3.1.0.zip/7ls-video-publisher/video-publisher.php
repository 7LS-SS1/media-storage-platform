<?php
/**
 * Compatibility loader for older installs that stored this file name.
 */

require_once __DIR__ . '/7ls-video-publisher.php';
